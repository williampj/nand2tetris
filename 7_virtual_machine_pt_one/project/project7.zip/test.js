"use strict";

var txt = "\npush constant 111\npush constant 333\npush constant 888\npop static 8\npop static 3\npop static 1\npush static 3\npush static 1\nsub\npush static 8\nadd";
var a = ['// This file is part of www.nand2tetris.org\n', '// and the book "The Elements of Computing Systems"\n', '// by Nisan and Schocken, MIT Press.\n', '// File name: projects/07/MemoryAccess/StaticTest/StaticTest.vm\n', '\n', '// Executes pop and push commands using the static segment.\n', 'push constant 111\n', 'push constant 333\n', 'push constant 888\n', 'pop static 8\n', 'pop static 3\n', 'pop static 1\n', 'push static 3\n', 'push static 1\n', 'sub\n', 'push static 8\n', 'add\n'];
var b = a.filter(function (line) {
  return !!line.trim() && !line.startsWith('//');
}).map(function (line) {
  return line.trim();
});
var c = txt.split('\r\n');
console.log(b);
// console.log(c);